﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Web.Mvc;
using System.Web.Security;
using TestApp.Filters;
using TestApp.Models;
using TestApp.ViewModels;
using WebMatrix.WebData;

namespace TestApp.Controllers
{
    [InitializeSimpleMembership]
    public class UsersRolesController : Controller
    {
        private UsersContext db = new UsersContext();

        //
        // GET: /UsersRoles/

        public ActionResult Index()
        {
            return View(db.UserProfiles.ToList());
        }

        //
        // GET: /UsersRoles/Details/5
     
        public ActionResult Details(int id = 0)
        {
            try
            {
                UserProfile userprofile = db.UserProfiles.Find(id);

                ViewBag.CreationDateTime = WebSecurity.GetCreateDate(userprofile.UserName).ToLocalTime();
                return View(userprofile);
            }
            catch(Exception ex)
            {
                ViewBag.Message = ex.InnerException;
                return View("Error");
            }
            
        }

        //
        // GET: /UsersRoles/Create

        public ActionResult Create()
        {
            var userViewModel = new UserProfileViewModel();
            return View(userViewModel);
        }

        //
        // POST: /UsersRoles/Create

        [HttpPost]
        public ActionResult Create(UserProfileViewModel userProfileModel)
        {
            //SHA1 sha = new SHA1CryptoServiceProvider();
            if (!ValidUserName(userProfileModel.UserProfile.UserName))
            {
                ModelState.AddModelError("userProfile.UserName","User exist");
                return View(userProfileModel);
            }
            if (ModelState.IsValid)
            {
                WebSecurity.CreateUserAndAccount(
                    userProfileModel.UserProfile.UserName,
                    userProfileModel.UserProfile.Password,
                    new {
                        userProfileModel.UserProfile.Email, 
                        userProfileModel.UserProfile.Adress, 
                        userProfileModel.UserProfile.SecurityKey,
                        userProfileModel.UserProfile.Password
                    });
                Roles.AddUserToRole(userProfileModel.UserProfile.UserName,db.SystemRoles.First(a=>a.RoleId==userProfileModel.RoleId).RoleName
                        );
                var id = db.UserProfiles.First(a => a.UserName == userProfileModel.UserProfile.UserName).UserId;
                return RedirectToAction("Details",new {id});
            }

            return View(userProfileModel);
        }
        public bool ValidUserName(string userName)
        {
            if (db.UserProfiles.FirstOrDefault(a=>a.UserName==userName)!=null)
            {
                return false;
            }
            return true;
        }

       

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}