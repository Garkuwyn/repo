﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using TestApp.Models;

namespace TestApp.ViewModels
{
    public class UserProfileViewModel
    {
        private UsersContext _usersContext;
        public UserProfileViewModel()
        {
            _usersContext = new UsersContext();
            this.UserProfile=new UserProfile();
            this.SystemRoles = _usersContext.SystemRoles.ToList();
        }
        public UserProfile UserProfile { get; set; }
        public List<SystemRole> SystemRoles { get; set; }
        [Required(ErrorMessage = "Please select role")]
        public int RoleId { get; set; }
    }
}