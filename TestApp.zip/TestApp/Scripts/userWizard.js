﻿$(function() {
    checkSelectState();
    $('#RoleId').change(function() {
        checkSelectState();
    });
});

function checkSelectState() {
    if ($('#RoleId :selected').text() == "Admin") {
        $("#adress_block").fadeOut('500', function () {
            $("#securityKey_block").fadeIn('500');
        });
    }
    else if ($('#RoleId :selected').text() == "User") {
        $("#securityKey_block").fadeOut('500', function () {
            $("#adress_block").fadeIn('500');
        });
    } else {
        $("#securityKey_block,#adress_block").hide();
    }
}